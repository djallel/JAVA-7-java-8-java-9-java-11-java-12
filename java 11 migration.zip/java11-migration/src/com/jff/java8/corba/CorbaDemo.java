package com.jff.java8.corba;



class CorbaDemo {
	

}