package com.jff.java7;

public class UnderscoreInNumericValue {

	public static void main(String[] args) {
		int creditCardNumber = 1234_5678;
		System.out.println("creditCardNumber :" + creditCardNumber);

	}
}
