package com.jff.java9.jshell;

public class JShellDemo {

	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println(100+200);
	}
}